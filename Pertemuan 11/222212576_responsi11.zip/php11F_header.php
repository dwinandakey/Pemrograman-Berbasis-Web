<header>
    <!-- Elemen navigasi -->
    <nav>
        <!-- Daftar item navigasi -->
        <ul>
            <!-- Item navigasi pertama -->
            <li>
                <!-- Tautan aktif menuju halaman 'Data Meeting' -->
                <a class="active" href="php11F.php">Data Meeting</a>
            </li>
            <!-- Item navigasi kedua, dengan margin kiri otomatis untuk mendorongnya ke kanan -->
            <li style="margin-left: auto;">
                <!-- Tautan menuju halaman logout -->
                <a href="php11F_logout.php">Logout</a>
            </li>
        </ul>
    </nav>
</header>
