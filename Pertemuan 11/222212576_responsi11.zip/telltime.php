<?php
    // Mengatur zona waktu menjadi 'Asia/Jakarta', yang sesuai dengan Waktu Indonesia Barat (WIB).
    // date_default_timezone_set('Asia/Jakarta'); // Zona waktu WIB

    // Mencetak tanggal saat ini dalam format 'YYYY-MM-DD'.
    echo date('Y-m-d ');

    // Mencetak waktu saat ini dalam format 'HH:MM:SS'.
    echo date('H:i:s');
?>
