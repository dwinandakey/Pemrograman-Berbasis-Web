<!DOCTYPE html>
<html lang='en-GB'>

<head>
    <title>PHP09 A</title>
</head>

<body>
    <?php
    // Menampilkan formulir untuk memasukkan item
    echo '
            <form action="php09B.php" method="post">
                <label>Item: <input type="text" name="item"></label>
            </form>
        ';
    ?>
</body>

</html>
